
import logo from '../assets/logo.svg';
import profile from '../assets/greg.jpeg';

/* eslint import/no-anonymous-default-export: [2, {"allowObject": true}] */
export default {
    logo,
    profile
};